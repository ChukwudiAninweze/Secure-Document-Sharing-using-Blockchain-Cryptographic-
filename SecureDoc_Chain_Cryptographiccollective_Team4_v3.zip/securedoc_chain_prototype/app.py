
import streamlit as st
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import secrets
import shutil
import uuid
from cryptography.fernet import Fernet, InvalidToken

APP_NAME = "SecureDoc Chain"
DATA_DIR = Path("data")
FILES_DIR = DATA_DIR / "encrypted_files"
LEDGER_FILE = DATA_DIR / "ledger.json"
DOCS_FILE = DATA_DIR / "documents.json"
MASTER_KEY_FILE = DATA_DIR / "master.key"

for folder in (DATA_DIR, FILES_DIR):
    folder.mkdir(parents=True, exist_ok=True)

def now_iso():
    return datetime.now(timezone.utc).isoformat()

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def canonical_json(data) -> str:
    return json.dumps(data, sort_keys=True, separators=(",", ":"))

def load_json(path: Path, default):
    if not path.exists():
        path.write_text(json.dumps(default, indent=2), encoding="utf-8")
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return default

def save_json(path: Path, data):
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")

def get_master_fernet():
    if not MASTER_KEY_FILE.exists():
        MASTER_KEY_FILE.write_bytes(Fernet.generate_key())
    return Fernet(MASTER_KEY_FILE.read_bytes())

def add_block(event_type: str, actor: str, document_id: str | None, payload: dict):
    ledger = load_json(LEDGER_FILE, [])
    previous_hash = ledger[-1]["block_hash"] if ledger else "0" * 64
    block = {
        "index": len(ledger),
        "timestamp": now_iso(),
        "event_type": event_type,
        "actor": actor,
        "document_id": document_id,
        "payload": payload,
        "previous_hash": previous_hash,
        "nonce": secrets.token_hex(4),
    }
    block["block_hash"] = sha256_bytes(canonical_json(block).encode())
    ledger.append(block)
    save_json(LEDGER_FILE, ledger)
    return block

def verify_chain():
    ledger = load_json(LEDGER_FILE, [])
    issues = []
    for i, block in enumerate(ledger):
        stored_hash = block.get("block_hash")
        clone = dict(block)
        clone.pop("block_hash", None)
        recalculated = sha256_bytes(canonical_json(clone).encode())
        expected_previous = "0" * 64 if i == 0 else ledger[i - 1]["block_hash"]
        if stored_hash != recalculated:
            issues.append(f"Block {i}: block hash mismatch")
        if block.get("previous_hash") != expected_previous:
            issues.append(f"Block {i}: previous-hash link broken")
    return len(issues) == 0, issues

def get_documents():
    return load_json(DOCS_FILE, [])

def save_documents(docs):
    save_json(DOCS_FILE, docs)

def find_doc(doc_id):
    for doc in get_documents():
        if doc["document_id"] == doc_id:
            return doc
    return None

def encrypt_document(file_bytes: bytes):
    document_key = Fernet.generate_key()
    encrypted = Fernet(document_key).encrypt(file_bytes)
    wrapped_key = get_master_fernet().encrypt(document_key).decode()
    return encrypted, wrapped_key

def decrypt_document(doc, encrypted_bytes):
    document_key = get_master_fernet().decrypt(doc["wrapped_key"].encode())
    return Fernet(document_key).decrypt(encrypted_bytes)

def reset_demo():
    if DATA_DIR.exists():
        shutil.rmtree(DATA_DIR)
    for folder in (DATA_DIR, FILES_DIR):
        folder.mkdir(parents=True, exist_ok=True)
    get_master_fernet()
    add_block("GENESIS", "system", None, {"message": "SecureDoc Chain ledger created"})

st.set_page_config(page_title=APP_NAME, page_icon="🔐", layout="wide")

st.markdown("""
<style>
.block-container {padding-top: 1.5rem;}
.hero {
    padding: 1.2rem 1.5rem;
    border: 1px solid rgba(100,100,100,.25);
    border-radius: 18px;
    margin-bottom: 1rem;
}
.metric-card {
    border: 1px solid rgba(100,100,100,.25);
    border-radius: 14px;
    padding: .9rem;
}
.small {font-size: .88rem; opacity: .8;}
code {word-break: break-all;}
</style>
""", unsafe_allow_html=True)

if not LEDGER_FILE.exists():
    reset_demo()

st.markdown("""
<div class="hero">
<h1>🔐 SecureDoc Chain</h1>
<p><b>Encrypted document sharing with blockchain-style integrity, access control and immutable audit evidence.</b></p>
<p><b>Built by Cryptographiccollective for the Cybersecurity Hackathon.</b></p>
<p class="small">Hackathon prototype: files stay off-chain and encrypted; only hashes, permissions and security events are written to the tamper-evident ledger.</p>
</div>
""", unsafe_allow_html=True)

with st.sidebar:
    st.header("Identity")
    current_user = st.text_input("Current User", value=st.session_state.get("user", "Cryptographiccollective"))
    current_user = current_user.strip() or "Cryptographiccollective"
    st.session_state["user"] = current_user
    st.caption("Owner: Cryptographiccollective | Shared with: Team4")
    st.divider()
    if st.button("♻️ Reset", use_container_width=True):
        reset_demo()
        st.success("Demo data reset.")
        st.rerun()
    st.warning("Prototype only: local key storage is used for an easy offline demonstration.")

docs = get_documents()
ledger = load_json(LEDGER_FILE, [])
chain_ok, chain_issues = verify_chain()

m1, m2, m3, m4 = st.columns(4)
m1.metric("Encrypted documents", len(docs))
m2.metric("Ledger blocks", len(ledger))
m3.metric("Current identity", current_user)
m4.metric("Ledger integrity", "VALID ✅" if chain_ok else "BROKEN ❌")

tabs = st.tabs([
    "1️⃣ Secure Upload",
    "2️⃣ Share Access",
    "3️⃣ Access Document",
    "4️⃣ Verify Integrity",
    "5️⃣ Attack Test",
    "6️⃣ Activity Log"
])

with tabs[0]:
    st.subheader("Upload, encrypt and register a document")
    uploaded = st.file_uploader("Choose a document", key="upload_doc")
    classification = st.selectbox(
        "Security classification",
        ["Public", "Internal", "Confidential", "Highly Confidential"],
        index=2
    )
    description = st.text_input("Purpose / description", placeholder="e.g., Hackathon judging brief")
    if uploaded and st.button("🔒 Encrypt and register", type="primary"):
        raw = uploaded.getvalue()
        plaintext_hash = sha256_bytes(raw)
        encrypted, wrapped_key = encrypt_document(raw)
        encrypted_hash = sha256_bytes(encrypted)
        doc_id = str(uuid.uuid4())[:12]
        stored_name = f"{doc_id}.secure"
        (FILES_DIR / stored_name).write_bytes(encrypted)

        doc = {
            "document_id": doc_id,
            "original_name": uploaded.name,
            "mime_type": uploaded.type or "application/octet-stream",
            "owner": current_user,
            "classification": classification,
            "description": description,
            "created_at": now_iso(),
            "plaintext_hash": plaintext_hash,
            "encrypted_hash": encrypted_hash,
            "wrapped_key": wrapped_key,
            "storage_file": stored_name,
            "allowed_users": [current_user],
            "revoked_users": [],
            "status": "ACTIVE"
        }
        docs = get_documents()
        docs.append(doc)
        save_documents(docs)
        block = add_block(
            "DOCUMENT_REGISTERED",
            current_user,
            doc_id,
            {
                "filename": uploaded.name,
                "classification": classification,
                "plaintext_hash": plaintext_hash,
                "encrypted_hash": encrypted_hash,
                "storage": "secure encrypted storage"
            }
        )
        st.success("Document encrypted and anchored to the ledger.")
        st.code(f"Document ID: {doc_id}\nSHA-256: {plaintext_hash}\nBlock: {block['block_hash']}")
        st.rerun()

    owned = [d for d in get_documents() if d["owner"] == current_user]
    if owned:
        st.markdown("#### Your protected documents")
        for d in owned:
            st.write(f"**{d['original_name']}** — `{d['document_id']}` — {d['classification']}")
            st.caption(f"Allowed users: {', '.join(d['allowed_users'])}")

with tabs[1]:
    st.subheader("Grant or revoke access through the permission ledger")
    owned = [d for d in get_documents() if d["owner"] == current_user and d["status"] == "ACTIVE"]
    if not owned:
        st.info("Upload a document as the current user first.")
    else:
        labels = {f"{d['original_name']} ({d['document_id']})": d for d in owned}
        selected_label = st.selectbox("Select owned document", list(labels.keys()))
        doc = labels[selected_label]
        recipient = st.text_input("Recipient identity", placeholder="Team4")
        c1, c2 = st.columns(2)
        with c1:
            if st.button("✅ Grant access", use_container_width=True):
                recipient_clean = recipient.strip()
                if not recipient_clean:
                    st.error("Enter a recipient identity.")
                else:
                    docs = get_documents()
                    for item in docs:
                        if item["document_id"] == doc["document_id"]:
                            if recipient_clean not in item["allowed_users"]:
                                item["allowed_users"].append(recipient_clean)
                            if recipient_clean in item["revoked_users"]:
                                item["revoked_users"].remove(recipient_clean)
                    save_documents(docs)
                    add_block("ACCESS_GRANTED", current_user, doc["document_id"], {"recipient": recipient_clean})
                    st.success(f"Access granted to {recipient_clean}.")
                    st.rerun()
        with c2:
            if st.button("⛔ Revoke access", use_container_width=True):
                recipient_clean = recipient.strip()
                if not recipient_clean:
                    st.error("Enter a recipient identity.")
                elif recipient_clean == current_user:
                    st.error("The owner cannot revoke their own access.")
                else:
                    docs = get_documents()
                    for item in docs:
                        if item["document_id"] == doc["document_id"]:
                            if recipient_clean in item["allowed_users"]:
                                item["allowed_users"].remove(recipient_clean)
                            if recipient_clean not in item["revoked_users"]:
                                item["revoked_users"].append(recipient_clean)
                    save_documents(docs)
                    add_block("ACCESS_REVOKED", current_user, doc["document_id"], {"recipient": recipient_clean})
                    st.warning(f"Access revoked for {recipient_clean}.")
                    st.rerun()
        st.info("Current allowed users: " + ", ".join(doc["allowed_users"]))

with tabs[2]:
    st.subheader("Open documents shared with the current identity")
    available = [
        d for d in get_documents()
        if current_user in d["allowed_users"] and d["status"] == "ACTIVE"
    ]
    if not available:
        st.info("No active documents are available to this identity.")
    else:
        labels = {f"{d['original_name']} — owner: {d['owner']} ({d['document_id']})": d for d in available}
        choice = st.selectbox("Available document", list(labels.keys()), key="open_choice")
        doc = labels[choice]
        path = FILES_DIR / doc["storage_file"]
        encrypted = path.read_bytes() if path.exists() else b""
        current_cipher_hash = sha256_bytes(encrypted) if encrypted else ""
        integrity_ok = encrypted and current_cipher_hash == doc["encrypted_hash"]

        st.write(f"**Classification:** {doc['classification']}")
        st.write(f"**Owner:** {doc['owner']}")
        st.write(f"**Encrypted storage integrity:** {'PASS ✅' if integrity_ok else 'FAIL ❌'}")

        if st.button("🔓 Authorise, verify and decrypt", type="primary"):
            if current_user not in doc["allowed_users"]:
                add_block("ACCESS_DENIED", current_user, doc["document_id"], {"reason": "Not on access list"})
                st.error("Access denied.")
            elif not integrity_ok:
                add_block("INTEGRITY_FAILURE", current_user, doc["document_id"], {"reason": "Encrypted file hash mismatch"})
                st.error("Decryption blocked because tampering was detected.")
            else:
                try:
                    plaintext = decrypt_document(doc, encrypted)
                    if sha256_bytes(plaintext) != doc["plaintext_hash"]:
                        add_block("INTEGRITY_FAILURE", current_user, doc["document_id"], {"reason": "Plaintext hash mismatch"})
                        st.error("Decrypted content failed integrity verification.")
                    else:
                        add_block("DOCUMENT_ACCESSED", current_user, doc["document_id"], {"result": "verified and decrypted"})
                        st.success("Identity authorised. Integrity verified. File decrypted.")
                        st.download_button(
                            "⬇️ Download verified document",
                            data=plaintext,
                            file_name=doc["original_name"],
                            mime=doc["mime_type"],
                            use_container_width=True
                        )
                except (InvalidToken, ValueError):
                    add_block("DECRYPTION_FAILED", current_user, doc["document_id"], {"reason": "Invalid encrypted content"})
                    st.error("The encrypted content or key is invalid.")

with tabs[3]:
    st.subheader("Independent document authenticity verification")
    verify_file = st.file_uploader("Upload a document to compare against the blockchain record", key="verify_file")
    all_docs = get_documents()
    if all_docs:
        labels = {f"{d['original_name']} ({d['document_id']})": d for d in all_docs}
        selected = st.selectbox("Choose registered record", list(labels.keys()), key="verify_record")
        doc = labels[selected]
        if verify_file and st.button("🧾 Verify SHA-256 fingerprint"):
            uploaded_hash = sha256_bytes(verify_file.getvalue())
            match = uploaded_hash == doc["plaintext_hash"]
            add_block(
                "EXTERNAL_VERIFICATION",
                current_user,
                doc["document_id"],
                {"submitted_hash": uploaded_hash, "result": "MATCH" if match else "MISMATCH"}
            )
            if match:
                st.success("AUTHENTIC ✅ — The document exactly matches the registered blockchain fingerprint.")
            else:
                st.error("TAMPERED / DIFFERENT ❌ — The document does not match the registered fingerprint.")
            st.code(f"Registered: {doc['plaintext_hash']}\nSubmitted:  {uploaded_hash}")
    else:
        st.info("No document record exists yet.")

with tabs[4]:
    st.subheader("Live cyberattack simulation")
    st.write("Demonstrate that an attacker can alter the stored ciphertext, but cannot silently bypass integrity checks.")
    all_docs = get_documents()
    if all_docs:
        labels = {f"{d['original_name']} ({d['document_id']})": d for d in all_docs}
        selected = st.selectbox("Target encrypted file", list(labels.keys()), key="tamper_target")
        doc = labels[selected]
        c1, c2 = st.columns(2)
        with c1:
            if st.button("💥 Simulate ciphertext tampering", use_container_width=True):
                path = FILES_DIR / doc["storage_file"]
                data = bytearray(path.read_bytes())
                if data:
                    position = min(20, len(data)-1)
                    data[position] = (data[position] + 1) % 256
                    path.write_bytes(bytes(data))
                    add_block("ATTACK_SIMULATED", current_user, doc["document_id"], {"attack": "ciphertext byte modification"})
                    st.error("A byte in the encrypted file was maliciously altered.")
                    st.rerun()
        with c2:
            if st.button("🛠️ Restore by re-encrypting placeholder", use_container_width=True):
                st.info("For a clean repeatable demo, use the sidebar reset and upload the original file again.")
        path = FILES_DIR / doc["storage_file"]
        current_hash = sha256_bytes(path.read_bytes()) if path.exists() else "missing"
        expected_hash = doc["encrypted_hash"]
        st.code(f"Expected ciphertext hash: {expected_hash}\nCurrent ciphertext hash:  {current_hash}")
        if current_hash == expected_hash:
            st.success("Storage is intact.")
        else:
            st.error("Tampering detected. Access and decryption will be blocked.")
    else:
        st.info("Upload a document first.")

with tabs[5]:
    st.subheader("Tamper-evident blockchain audit trail")
    valid, issues = verify_chain()
    if valid:
        st.success("Every block hash and previous-hash link is valid.")
    else:
        st.error("Ledger integrity is broken.")
        for issue in issues:
            st.write(issue)

    ledger = load_json(LEDGER_FILE, [])
    event_filter = st.multiselect(
        "Filter events",
        sorted({b["event_type"] for b in ledger}),
        default=[]
    )
    filtered = [b for b in reversed(ledger) if not event_filter or b["event_type"] in event_filter]
    for block in filtered[:50]:
        with st.expander(f"Block {block['index']} · {block['event_type']} · {block['actor']}"):
            st.json(block)

    st.download_button(
        "⬇️ Export audit ledger",
        data=json.dumps(ledger, indent=2),
        file_name="securedoc_chain_ledger.json",
        mime="application/json",
        use_container_width=True
    )
