# Judge Pitch and Demonstration Script

## 30-second opening

“SecureDoc Chain protects sensitive documents against unauthorised access, hidden modification and weak accountability. The file is encrypted and stored off-chain, while its SHA-256 fingerprint, access permissions and security events are placed in a tamper-evident blockchain-style ledger. This gives confidentiality, integrity, controlled sharing and undeniable audit evidence.”

## Demonstration sequence

### 1. Protect the document
- Identity: Cryptographiccollective
- Upload a document.
- Select “Highly Confidential”.
- Encrypt and register it.
- Point out the document ID, SHA-256 fingerprint and block hash.

### 2. Grant controlled access
- Grant Team4 access.
- Explain that permission changes become auditable ledger events.

### 3. Prove authorised access
- Change identity to Team4.
- Open the shared file.
- Show that the system verifies ciphertext integrity before decryption.
- Download the verified document.

### 4. Simulate an attack
- Change identity to Cryptographiccollective.
- Use Threat Simulation to alter one encrypted byte.
- Change identity to Team4 and attempt access again.
- Show that the system detects the changed hash and blocks decryption.

### 5. Show forensic evidence
- Open Blockchain Audit.
- Display the chained blocks for registration, permission, access and attack events.
- Export the ledger as JSON.

## Strong closing statement

“Our prototype applies zero-trust principles: access is explicitly granted, data remains encrypted, every file is verified before use, and every security-relevant action leaves tamper-evident evidence. The same design can protect university research, legal records, healthcare files, financial reports and government documents.”
